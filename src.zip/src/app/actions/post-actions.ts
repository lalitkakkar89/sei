import { createAction, props } from '@ngrx/store';

export const POST_LIST_REQUEST = 'post list request';
export const POST_LIST_SUCCESS = 'post list sucess';
export const POST_LIST_FAILED = 'post list failed';
export const POST_SELECT = 'post select';

export class postListRequestAction {
  readonly type = POST_LIST_REQUEST;
}

export class postListSucessAction {
  readonly type = POST_LIST_SUCCESS;
  constructor(public payload?: { data: any[] }) {}
}

export class postSelectAction {
  readonly type = POST_SELECT;
  constructor(public payload?: { id: [] }) {}
}
