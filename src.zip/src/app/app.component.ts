import { Component, OnInit } from '@angular/core';
import {
  FormArray,
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { Store } from '@ngrx/store';
import { combineLatest, forkJoin, Observable } from 'rxjs';
import { debounceTime, distinctUntilChanged, switchMap } from 'rxjs/operators';
import { MainserviceService } from './services/mainservice.service';
import { ListserviceService } from './services/listservice.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent {
  searchForm: FormGroup;
  items: any[] = []; // Replace 'any' with your actual item type
  selectedItems: any;
  apiResults$: any;

  constructor(
    private fb: FormBuilder,
    private mainService: MainserviceService,
    public listService: ListserviceService
  ) {}

  ngOnInit(): void {
    this.initForm();
    this.setupFormChanges();
  }

  initForm() {
    this.searchForm = this.fb.group({
      searchText: ['', [Validators.minLength(2)]],
      selectedItems: this.fb.array([]), // Initialize the form array for selected items
    });
  }

  // setupFormChanges() {
  //   const loading$ = this.store.select(getPostLoading);
  //   const loaded$ = this.store.select(getPostLoaded);
  //   const getPostsData = this.store.select(getPosts);

  //   combineLatest([loaded$, loading$]).subscribe((data) => {
  //     if (!data[0] && !data[1]) {
  //       this.store.dispatch(new postListRequestAction());
  //       this.searchForm
  //         .get('searchText')
  //         .valueChanges.pipe(
  //           debounceTime(2000), // Debounce for 2 seconds
  //           distinctUntilChanged(), // Only emit when the value has changed
  //           switchMap((value) => this.apiService.getData())
  //         )
  //         .subscribe((response: any) => {
  //           //this.items = response;
  //           //console.log(response);
  //           this.store.dispatch(new postListSucessAction({ data: response }));
  //         });
  //     }
  //   });

  //   getPostsData.subscribe((data) => {
  //     this.items = data;
  //     console.log(data);
  //   });
  // }

  setupFormChanges() {
    this.searchForm
      .get('searchText')
      .valueChanges.pipe(
        debounceTime(2000), // Debounce for 2 seconds
        distinctUntilChanged(), // Only emit when the value has changed
        switchMap((value) => this.mainService.getPostList()[1])
      )
      .subscribe((response) => {
        this.items = response;
      });
  }

  get selectedItemsFormArray() {
    return this.searchForm.get('selectedItems') as FormArray;
  }

  onCheckboxChange(event: any, item: any) {
    if (event.target.checked) {
      this.selectedItemsFormArray.push(new FormControl(item));
    } else {
      const index = this.selectedItemsFormArray.controls.findIndex(
        (control) => control.value === item
      );
      this.selectedItemsFormArray.removeAt(index);
    }
  }

  // callApis(): void {
  //   // console.log(this.selectedItemsFormArray.value);
  //   let selectedValues = this.selectedItemsFormArray.value;
  //   this.selectedItems = selectedValues.map((id) => id.id);
  //   //console.log(this.selectedItems);
  //   const apiCalls: Observable<any>[] = Array.from(this.selectedItems).map(
  //     (itemId) => this.listService.getPostData(itemId)
  //   );
  //   //console.log(apiCalls);
  //   this.apiResults$ = forkJoin(apiCalls).subscribe((res) => {});
  // }

  callApis(): void {
    let selectedValues = this.selectedItemsFormArray.value;
    this.selectedItems = selectedValues.map((id) => id.id);
    this.mainService.selectedPost(this.selectedItems).subscribe((res) => {
      //console.log(res);
      // this.items = response;
    });
  }
}
