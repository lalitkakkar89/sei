import { ActionReducerMap, createSelector } from '@ngrx/store';
import * as fromPosts from './post-reducer';

export interface RootReducerState {
  posts: fromPosts.PostReducerState;
}

export const rootReducer: ActionReducerMap<RootReducerState> = {
  posts: fromPosts.postReducer,
};

export const getPostsState = (state: RootReducerState) => state.posts;
export const getPostLoaded = createSelector(getPostsState, fromPosts.getLoaded);
export const getPostLoading = createSelector(
  getPostsState,
  fromPosts.getLoading
);
export const getPosts = createSelector(getPostsState, fromPosts.getPosts);
