import { createReducer, on } from '@ngrx/store';
import { Action } from '../actions';
import {
  POST_LIST_REQUEST,
  POST_LIST_SUCCESS,
  POST_SELECT,
} from '../actions/post-actions';

export interface PostReducerState {
  loading: boolean;
  loaded: boolean;
  posts: [];
}

export interface ItemState {
  //loading: boolean;
  //loaded: boolean;
  selectedItems: Set<number>;
  apiResults: { [itemId: number]: any };
  error: { [itemId: number]: any };
}

const initialState: PostReducerState = {
  loaded: false,
  loading: false,
  posts: [],
};

const liistInitialState: ItemState = {
  //loaded: false,
  // loading: false,
  selectedItems: new Set<number>(),
  apiResults: {},
  error: {},
};

export function postReducer(
  state = initialState,
  action: Action
): PostReducerState {
  switch (action.type) {
    case POST_LIST_REQUEST: {
      return { ...state, loading: true };
    }
    case POST_LIST_SUCCESS: {
      //const updatedPosts: any = state.posts.concat(action.payload.data);
      const updatedPosts: any = action.payload.data;
      return { ...state, loading: false, loaded: true, posts: updatedPosts };
    }
    case POST_SELECT: {
      return { ...state };
    }
    default: {
      return state;
    }
  }
}

export const getLoading = (state: PostReducerState) => state.loading;
export const getLoaded = (state: PostReducerState) => state.loaded;
export const getPosts = (state: PostReducerState) => state.posts;
