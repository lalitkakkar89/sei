import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class ListserviceService {
  constructor(readonly http: HttpClient) {}

  getData() {
    return this.http.get(`https://jsonplaceholder.typicode.com/posts`);
  }

  getPostData(id: any): Observable<any> {
    return this.http.get(`https://jsonplaceholder.typicode.com/posts/${id}`);
  }
}
