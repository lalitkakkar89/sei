import { Injectable } from '@angular/core';
import { Store } from '@ngrx/store';
import { combineLatest, forkJoin, Observable } from 'rxjs';
import {
  postListRequestAction,
  postListSucessAction,
  postSelectAction,
} from '../actions/post-actions';
import {
  getPostLoaded,
  getPostLoading,
  getPosts,
  RootReducerState,
} from '../reducers';
import { ListserviceService } from '../services/listservice.service';

@Injectable({
  providedIn: 'root',
})
export class MainserviceService {
  apiResults$: any;
  constructor(
    private apiService: ListserviceService,
    private store: Store<RootReducerState>
  ) {}

  getPostList(): [Observable<boolean>, Observable<any>] {
    const loading$ = this.store.select(getPostLoading);
    const loaded$ = this.store.select(getPostLoaded);
    const getPostsData = this.store.select(getPosts);

    combineLatest([loaded$, loading$]).subscribe((data) => {
      if (!data[0] && !data[1]) {
        this.store.dispatch(new postListRequestAction());
        this.apiService.getData().subscribe((response: any) => {
          this.store.dispatch(new postListSucessAction({ data: response }));
        });
      }
    });
    return [loaded$, getPostsData];
  }

  // callApis(): void {
  //   // console.log(this.selectedItemsFormArray.value);
  //   let selectedValues = this.selectedItemsFormArray.value;
  //   this.selectedItems = selectedValues.map((id) => id.id);
  //   //console.log(this.selectedItems);
  //   const apiCalls: Observable<any>[] = Array.from(this.selectedItems).map(
  //     (itemId) => this.listService.getPostData(itemId)
  //   );
  //   //console.log(apiCalls);
  //   this.apiResults$ = forkJoin(apiCalls).subscribe((res) => {});
  // }

  selectedPost(id: []) {
    const getPostsData = this.store.select(getPosts);
    this.store.dispatch(new postSelectAction({ id }));
    const apiCalls: Observable<any>[] = Array.from(id).map((itemId) =>
      this.apiService.getPostData(itemId)
    );
    forkJoin(apiCalls).subscribe((res) => {
      this.store.dispatch(new postListSucessAction({ data: res }));
    });
    return getPostsData;
  }
}
